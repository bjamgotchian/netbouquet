﻿<HTML>
<BODY>
<?php
$prenom="Votre prénom";
echo "Bonjour ".strtoupper($prenom)."<br>";
echo "Nous sommes le ". date('d/m/y')."<br> il est ".date('H:i:s')."<br>";
?>
<hr size= "2">

<?php
$tableau[]="occurrence";
$tableau[]="e";
$tableau[]=1.5;
$tableau[]=1;
$tableau[]=true;

echo gettype($tableau);
echo"<br>";
	for ($i=0; $i<5; $i++)
	{
		echo $tableau[$i]." : "; 
		echo gettype($tableau[$i])."<br>";
	}
$chaine1=$tableau[0]+$tableau[1]+$tableau[2]+$tableau[3]+$tableau[4];
echo $chaine1;
echo"<br>";
$chaine2=$tableau[0].$tableau[1].$tableau[2].$tableau[3].$tableau[4];
echo $chaine2;
$variableTest = 1;
echo $variableTest."<br>";
echo $variableTest."<br>";
$variableTest = "Bonjour php";
echo "Sous chaine de 2 caracteres commencant à la position 3 : " .substr($variableTest,3,2)."<br>";
?>
